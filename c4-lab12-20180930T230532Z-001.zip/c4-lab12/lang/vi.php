<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>vi</title>
</head>

<body>
	<?php
    	define("HOME","Trang Chủ");
		define("CONTACT","Liên Hệ");
		define("INTRODUCTION","Giới Thiệu");
		define("LOGIN","Đăng nhập");
		
		define("ENGLISH","Tiếng Anh");
		define("VIETNAMESE","Tiếng Việt");
		
		define("WELCOME","Chào mừng các bạn đến với website của tôi!");
		
		define("CONTACT_FORM"," Form liên hệ");
		define("NAME","Họ tên");
		define("BIRTHDAY","Ngày sinh");
		define("ADDRESS","Địa chỉ");
		define("MAIL","Hòm thư");
		define("TEL","Số điện thoại");
		define("NOTE","Ghi chú");
		define("RESET","Nhập lại");
		define("SEND","Gửi");
	?>
</body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>eng</title>
</head>

<body>
	<?php
    	define("HOME","Home");
		define("CONTACT","Contact");
		define("INTRODUCTION","Introduction");
		define("LOGIN","Login");
		
		define("ENGLISH","English");
		define("VIETNAMESE","Vietnamese");
		
		define("WELCOME","Welcome to my website!");
		
		define("CONTACT_FORM"," Contact Form");
		define("NAME","User Name");
		define("BIRTHDAY","Birthday");
		define("ADDRESS","Address");
		define("MAIL","Mail");
		define("TEL","Tel");
		define("NOTE","Note");
		define("RESET","Reset");
		define("SEND","Send");
	?>
</body>
</html>
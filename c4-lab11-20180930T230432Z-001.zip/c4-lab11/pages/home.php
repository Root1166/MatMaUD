<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>home</title>
</head>

<body>
	<em style="color:#F00; font-size:16px; margin-left:30px;"><strong>Chú ý bài này:</strong> Khuyến khích dùng <strong>Database</strong> vừa khoa học lại vừa đơn giản, dùng file phức tạp mà lỗi tùm lum. <br />
    Còn những lỗi sau chưa giải quyết được <strong>khi dùng file</strong>:<br />
    <strong>1</strong>-mục hiển thị list students vẫn còn dư ra 1 trường thông tin chả biết ở đâu ra @@ <br />
    <strong>2</strong>-phần detail edit delete chỉ hiển thị được thằng ở vị trí đầu tiên <br />
    <strong>3</strong>-edit không update được-delete không có ý tưởng -_- <br /></em>
</body>
</html>
<?php
	echo "Không có ý tưởng khác ngoài việc dùng database <br>";
	echo "<a href='?ac=list'>Back to List Students</a>";
?>